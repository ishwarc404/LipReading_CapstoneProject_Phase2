# Welcome to the demo folder
1. You must have wxpython, gTTS and pygame installed.
2. wxpython is for the gui and pygame is for the audio piping. gTTS is used for text to audio conversion.
3. The gui.py controls everything. 

# To run
python3 gui.py
